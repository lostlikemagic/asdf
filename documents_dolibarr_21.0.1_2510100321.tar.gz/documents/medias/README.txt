# File(s) into root medias directory are provide by Pixabay with Licence "CC0 Creative Commons"
# https://creativecommons.org/publicdomain/zero/1.0/
